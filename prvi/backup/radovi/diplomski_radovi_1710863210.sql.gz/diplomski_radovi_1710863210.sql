INSERT INTO diplomski_radovi (id, naziv_rada, tekst_rada, link_rada, oib_tvrtke) VALUES ('0', 'admin', 'Obzirom na potrebu realizacije studija, režije i montaže Studentskog radija UNIOS, u kojem bi se omo', 'https://stup.ferit.hr/author/admin/', '2147483647');
INSERT INTO diplomski_radovi (id, naziv_rada, tekst_rada, link_rada, oib_tvrtke) VALUES ('123456', 'test', 'test123', '123test', '82645');
